export default function Preloader() {
    return (
        <>
            <div className="preloader" />
        </>
    )
}
